import streamlit as st
import sqlite3
import pandas as pd
from datetime import date, datetime
import bcrypt

DB_PATH = 'household.db'

def get_db():
    conn = sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cursor = conn.cursor()
    return conn, cursor

def create_tables():
    conn, cursor = get_db()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            t_type TEXT NOT NULL CHECK (t_type IN ('소득', '지출')),
            amount REAL NOT NULL CHECK(amount > 0),
            category TEXT NOT NULL,
            description TEXT,
            transaction_date TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    conn.commit()
    conn.close()

def hash_password(password: str) -> bytes:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

def check_password(password: str, hashed: bytes) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed)

def signup(username: str, password: str) -> bool:
    conn, cursor = get_db()
    try:
        hashed = hash_password(password)
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def login(username: str, password: str):
    conn, cursor = get_db()
    cursor.execute('SELECT id, password FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    conn.close()
    if user:
        user_id, hashed_pw = user
        if check_password(password, hashed_pw):
            return user_id
    return None

def add_transaction(user_id, t_type, amount, category, description, transaction_date):
    conn, cursor = get_db()
    cursor.execute('''
        INSERT INTO transactions (user_id, t_type, amount, category, description, transaction_date)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (user_id, t_type, amount, category, description, transaction_date))
    conn.commit()
    conn.close()

def get_transactions(user_id, filter_month):
    conn, cursor = get_db()
    query = '''
        SELECT * FROM transactions
        WHERE user_id = ? AND strftime('%Y-%m', transaction_date) = ?
        ORDER BY transaction_date DESC
    '''
    df = pd.read_sql_query(query, conn, params=(user_id, filter_month))
    conn.close()
    return df

def delete_transaction(transaction_id):
    conn, cursor = get_db()
    cursor.execute('DELETE FROM transactions WHERE id = ?', (transaction_id,))
    conn.commit()
    conn.close()

# 변경된 함수: income과 expense를 날짜별로 합산해 데이터프레임으로 리턴
def summarize_income_expense_by_day(df):
    if df.empty:
        return None
    df['transaction_date'] = pd.to_datetime(df['transaction_date'])
    # 날짜만 추출 (일)
    df['day'] = df['transaction_date'].dt.day

    # income, expense 각각 그룹화하여 합산
    income = df[df['t_type'] == 'income'].groupby('day')['amount'].sum()
    expense = df[df['t_type'] == 'expense'].groupby('day')['amount'].sum()

    # 1~31일 인덱스 생성
    all_days = pd.Series(range(1, 32))

    # 인덱스를 맞춰서 NaN은 0으로 채움
    income = income.reindex(all_days, fill_value=0)
    expense = expense.reindex(all_days, fill_value=0)

    # 데이터프레임으로 합치기
    summary = pd.DataFrame({'소득': income, '': expense})
    return summary

def valid_month_format(month_str):
    try:
        datetime.strptime(month_str, "%Y-%m")
        return True
    except ValueError:
        return False

def main():
    create_tables()

    if 'user_id' not in st.session_state:
        st.session_state['user_id'] = None
    if 'username' not in st.session_state:
        st.session_state['username'] = None
    if 'delete_confirm' not in st.session_state:
        st.session_state['delete_confirm'] = None

    st.title("📒 간단 가계부 앱")

    if st.session_state['user_id'] is None:
        st.sidebar.header("회원가입 / 로그인")
        menu = st.sidebar.selectbox("선택하세요", ["로그인", "회원가입"])

        if menu == "회원가입":
            new_username = st.sidebar.text_input("아이디 (최대 15자)", max_chars=15, key="signup_username")
            new_password = st.sidebar.text_input("비밀번호 (최대 15자)", type="password", max_chars=15, key="signup_password")
            new_password_confirm = st.sidebar.text_input("비밀번호 확인", type="password", max_chars=15, key="signup_password_confirm")
            if st.sidebar.button("회원가입"):
                if not new_username or not new_password or not new_password_confirm:
                    st.sidebar.error("아이디와 비밀번호(2회)를 모두 입력하세요.")
                elif len(new_username) > 15 or len(new_password) > 15:
                    st.sidebar.error("아이디와 비밀번호는 최대 15자까지 가능합니다.")
                elif new_password != new_password_confirm:
                    st.sidebar.error("비밀번호가 일치하지 않습니다.")
                elif signup(new_username, new_password):
                    st.sidebar.success("회원가입 성공! 로그인 해주세요.")
                else:
                    st.sidebar.error("이미 존재하는 아이디입니다.")
        else:
            username = st.sidebar.text_input("아이디 (최대 15자)", max_chars=15, key="login_username")
            password = st.sidebar.text_input("비밀번호 (최대 15자)", type="password", max_chars=15, key="login_password")
            if st.sidebar.button("로그인"):
                user_id = login(username, password)
                if user_id:
                    st.session_state['user_id'] = user_id
                    st.session_state['username'] = username
                    st.experimental_rerun()
                else:
                    st.sidebar.error("로그인 실패: 아이디 또는 비밀번호가 맞지 않습니다.")

    else:
        st.sidebar.write(f"👤 로그인: {st.session_state['username']}")
        if st.sidebar.button("로그아웃"):
            st.session_state['user_id'] = None
            st.session_state['username'] = None
            st.experimental_rerun()

        user_id = st.session_state['user_id']

        filter_month = st.sidebar.text_input("조회할 월 (YYYY-MM)", value=date.today().strftime("%Y-%m"))

        if not valid_month_format(filter_month):
            st.sidebar.error("월 입력 형식이 올바르지 않습니다. (예: 2024-09)")
            return

        st.header("📋 거래 내역 등록")
        with st.form("transaction_form"):
            t_type = st.selectbox("유형", ["소득", "지출"])
            amount = st.number_input("금액", min_value=0.0, step=1000.0)
            category = st.text_input("카테고리")
            description = st.text_area("설명 (선택)")
            transaction_date = st.date_input("날짜", value=date.today())
            submitted = st.form_submit_button("저장")

            if submitted:
                if amount <= 0:
                    st.error("금액은 0보다 커야 합니다.")
                elif category.strip() == "":
                    st.error("카테고리를 입력하세요.")
                else:
                    add_transaction(user_id, t_type, amount, category.strip(), description.strip(), transaction_date.strftime("%Y-%m-%d"))
                    st.success("거래 내역이 저장되었습니다.")
                    st.experimental_rerun()

        st.header("📋 거래 내역")
        df = get_transactions(user_id, filter_month)

        if df.empty:
            st.info("해당 기간의 거래 내역이 없습니다.")
        else:
            for idx, row in df.iterrows():
                col1, col2, col3, col4, col5, col6 = st.columns([1,1,1,2,2,1])
                col1.write(row['transaction_date'])
                col2.write(row['t_type'])
                amount_display = row['amount'] if row['t_type'] == 'income' else -row['amount']
                col3.write(f"{amount_display:,}")
                col4.write(row['category'])
                col5.write(row['description'])
                if st.session_state['delete_confirm'] == row['id']:
                    col6.warning("삭제하시겠습니까?")
                    if col6.button("확인", key=f"confirm_del_{row['id']}"):
                        delete_transaction(row['id'])
                        st.session_state['delete_confirm'] = None
                        st.experimental_rerun()
                    if col6.button("취소", key=f"cancel_del_{row['id']}"):
                        st.session_state['delete_confirm'] = None
                        st.experimental_rerun()
                else:
                    if col6.button("삭제", key=f"del_{row['id']}"):
                        st.session_state['delete_confirm'] = row['id']
                        st.experimental_rerun()

        st.header("📊 월별 소비 패턴 요약")
        summary = summarize_income_expense_by_day(df)
        if summary is None or summary.empty:
            st.info("해당 기간에 지출 또는 소득 내역이 없습니다.")
        else:
            st.bar_chart(summary)

if __name__ == "__main__":
    main()
